<?php  
$conn=mysqli_connect("localhost", "root", "","internship");
if($conn == false)
{
	die("error in connection");
}

 ?>